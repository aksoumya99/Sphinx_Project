
<?php
	session_start();

	if (isset($_SESSION['username'])) {
		include 'loggedin.php';
	}
	else{
		header('location:homepage.php');
	}

?> 

<center><b><br>Quizes</b></center>
<hr>

<br><br>
Select Quiz to add ques: 
<br>

<?php
	
	$con = mysqli_connect("localhost" , "root" , "");
	mysqli_select_db($con,"sphinx");

	$query = "SELECT * FROM quizes";
	$result = mysqli_query($con,$query);

	echo "<ul>";
	while($rows = mysqli_fetch_array($result)){
		echo "<li> $rows[0] <form display='inline' method='GET' action='questions.php'>".
								"<input type='hidden' value='$rows[1]' name='quiz_code'>".
								"<input type='submit' value='Select Quiz'>".
						   "</form>".
		"</li>";
	}
?>

<br><br>
<a href="newquiz.php">Add a new quiz</a> 
<br>

