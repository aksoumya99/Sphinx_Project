<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	

	<?php 
	if(!isset($_SESSION['username'])){
		session_start();
		if(isset($_SESSION['posthour']))
		{
			include 'unsetquiztimer.php';
		}
	}
	echo "Welcome <b>'".$_SESSION['username']."'</b> , you are logged..in !!!"; 
	?>
	
	

	<a href="logout.php" style="appearance: button;text-decoration: none;-webkit-appearance: button
	;-moz-appearance: button;">logout</a>

	
	  
	<ul>
		<li><a href="homepage.php">home</a></li>
		<li><a href="contact.php">contact</a></li>
		<li><a href="leaderboard.php">leaderboard</a></li>
		<li><a href="#">random</a></li>

		<?php
			$con = mysqli_connect("localhost" , "root" , "");
			mysqli_select_db($con,"sphinx");
			$username = $_SESSION['username'];
			$result = mysqli_query($con,"SELECT * FROM users WHERE username='$username';");
			$row = mysqli_fetch_array($result);

			if($row['admin'] == 1){ 
		?>
		<li><a href="addquesquiz.php">Add Ques/Quiz</a></li>
		<li><a href="check_sub.php">Check Questions</a></li>
		<?php  
			}
		?>
		
	</ul>
	


</body>
</html>