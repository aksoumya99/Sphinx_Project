<?php

  if(isset($_GET['create']))
  {
    session_start();
    if(isset($_SESSION['posthour']))
    {
      include 'unsetquiztimer.php';
    }
    //echo "Welcome <b>'".$_SESSION['name']."'</b>";
    $_SESSION['username']=$_GET['username'];
    $_SESSION['mobile']=$_GET['mobile'];
    //echo "Welcome <b>'".$_SESSION['mobile']."'</b>";
    header('location:fbregredirect.php');
    //exit();
  }

  ?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <h2>One last step</h2>
  <br>
  <h4>fill these details</h4>
  <br>
<div>
  <form method="GET" action="regfb.php">
  Username : <br>
  <input type="text" name="username" required="required">
  <br>
  Mobile number: <br>
  <input type="number" name="mobile" required="required"><br>
  <input type="submit" name="create" value="submit">
  </form>
</div>
</body>
</html>