<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	you are loggedout....
	<a href="login.php">Login</a>

	<!--navbar to be used here
		home
		contact
		help
		quizes
		leaderboard
	-->

	
</body>
</html>