<?php
	session_start();
	if(isset($_SESSION['posthour']))
	{
		include 'unsetquiztimer.php';
	}
	if(isset($_SESSION['username'])) {
		include 'loggedin.php';
	}
	
	
	else{
		include 'loggedout.php';
	}
?>

<br><br><br>

<div>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</div>

<br>
<br>
<br>

Quizes to participate in : <br>

<?php
	$con=mysqli_connect("localhost", "root" , "");
	mysqli_select_db($con,"sphinx");

	$query = "SELECT name,qcode FROM quizes";
	$result = mysqli_query($con,$query);

	echo "<ul>";
	while($rows = mysqli_fetch_array($result)){
		echo "<li> $rows[0] <form method='GET' action='enterquiz.php'>".
								"<input type='hidden' value='$rows[1]' name='quiz_code'>".
								"<input type='submit' value='Enter Quiz'>".
						   "</form>".
		"</li>";
	}	
	echo "</ul>";

?>