<?php
	session_start();
	if(isset($_SESSION['posthour']))
	{
		include 'unsetquiztimer.php';
	}
	if (isset($_SESSION['username'])) {
		include 'loggedin.php';
	}
	else{
		header('location:homepage.php');
	}

	$con = mysqli_connect("localhost","root","");
	mysqli_select_db($con,"sphinx");

	$query = "SELECT DISTINCT qcode FROM marks WHERE eva_status='0'";
	$result = mysqli_query($con,$query);
	$num = mysqli_num_rows($result);

	if($num > 0){
		echo "<ul>";
	while($rows = mysqli_fetch_array($result)){
		$quiz_code = $rows['qcode'];
		$query = "SELECT name FROM quizes WHERE qcode='$quiz_code'";
		$qname_result = mysqli_query($con,$query);
		$qname_row = mysqli_fetch_array($qname_result);
		$quiz_name = $qname_row['name'];

		echo "<li> $quiz_name <form method='GET' action='check_sub_user.php'>".
								"<input type='hidden' value='$quiz_code' name='quiz_code'>".
								"<input type='submit' value='evaluate Quiz'>".
						   "</form>".
		"</li>";
	}	
	echo "</ul>";
	}
	else{
		echo "no quizes to be evaluated ^_^";
		echo "<a href='homepage.php'>return to homepage</a>";
	}
?>