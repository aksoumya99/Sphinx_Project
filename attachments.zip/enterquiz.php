<?php
	session_start();
	if(isset($_SESSION['posthour']))
	{
		include 'unsetquiztimer.php';
	}
	if(isset($_SESSION['username'])){
		include 'loggedin.php';
	}

	else{
		include 'loggedout.php';
		die("you need to be logged in");
	}


	$quiz_code = $_GET['quiz_code'];
	$_SESSION['quiz_code'] = $quiz_code;

	$con=mysqli_connect("localhost" , "root" , "");
	mysqli_select_db($con,"sphinx");

	$query = "SELECT * FROM quizes WHERE qcode='$quiz_code'";
	$result = mysqli_query($con,$query);

	$row = mysqli_fetch_array($result);
	$_SESSION['quiz_name'] = $row[0];
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<br><br><br>
	<div>
		<?php echo "$row[0]"; ?> <!--name of the quiz -->
	</div>
	<br>
	<div>
		<?php echo "will be held on $row[2]"; ?> <!--schedule of the quiz -->
	</div>
	<br>
	<div>
		<?php echo "duration : $row[3] mins"; ?> <!--duration of the quiz -->
	</div>
	<br>
	<div>
		<?php echo "Type : $row[4]"; ?> <!--type of the quiz -->
	</div>
	<br>
	<div>
		<?php echo "About <br>$row[5]"; ?> <!--about the quiz -->
	</div>
	<br>
	<div>
		<a href="commentindex.php">Discussion Forum</a>
	<form method="GET" action="reg_for_quiz.php">
		<input type="hidden" name="quiz_code" value="<?php echo "$row[1]"; ?>">
		<input type="submit" value="Register for Quiz">
	</form>
</body>
</html>