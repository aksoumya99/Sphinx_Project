<?php
	session_start();
	if (isset($_SESSION['username'])) {
		include 'loggedin.php';
	}
	else{
		header('location:homepage.php');
	}

	$num_of_ques = $_SESSION['num_of_ques'];
	$ques_seq = $_SESSION['ques_seq'];
	$quiz_code = $_SESSION['quiz_code'];
	$username = $_SESSION['username'];

	$con = mysqli_connect("localhost" , "root" , "");
	mysqli_select_db($con,"sphinx");
	//Timer Code
	//session_start();
	$query= "SELECT * FROM quizes WHERE qcode='$quiz_code'";
	$result=mysqli_query($con,$query);
	$row=mysqli_fetch_assoc($result);
	$duration=$row["duration"];
	$arr=explode(":",$duration);
	$hr=$arr[0];
	$min=$arr[1];
	$sec=$arr[2];
	if(isset($_SESSION['posthour']))
	{
		$hr=$_SESSION['posthour'];
		$min=$_SESSION['postmin'];
		$sec=$_SESSION['postsec'];
	}
	$rem=((int)$hr)*3600+((int)$min)*60+((int)$sec);
	?>
	<div id="totalsecs" style="display: none;">
    <?php
        echo htmlspecialchars($rem); 
    ?>
</div>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
</head>
<body><!-- 
<h1>Countdown Clock</h1> -->
<div id="clockdiv">
  <div>
    
  </div>
  <div>
    <span class="hours"></span>
    <div class="smalltext">Hours</div>
  </div>
  <div>
    <span class="minutes"></span>
    <div class="smalltext">Minutes</div>
  </div>
  <div>
    <span class="seconds"></span>
    <div class="smalltext">Seconds</div>
  </div>
</div>
<script type="text/javascript">
 function preventBack() {window.history.forward();}
	setTimeout("preventBack()",0);
	window.onunload = function(){null};
function initializeClock(id, endtime) {
  var clock = document.getElementById(id);
  var hoursSpan = clock.querySelector('.hours');
  var minutesSpan = clock.querySelector('.minutes');
  var secondsSpan = clock.querySelector('.seconds');
  var totalsecs = document.getElementById("totalsecs");
  total = totalsecs.textContent;
  function updateClock() {
    var seconds = total;
	var minutes = Math.floor(seconds / 60);
	var hours = Math.floor(minutes/ 60);
	hours %= 24;
	minutes %= 60;
	seconds %= 60;
	$.post('validatenew.php',{posthour:hours,postmin:minutes,postsec:seconds},
		function(data)
		{
			;
		});
    hoursSpan.innerHTML = ('0' + hours).slice(-2);
    minutesSpan.innerHTML = ('0' + minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + seconds).slice(-2);
    total=total-1;
    if (total <= 0) {
      clearInterval(timeinterval);
    }
  }

  updateClock();
  var timeinterval = setInterval(updateClock, 1000);
}

var deadline = new Date(Date.parse(new Date()) + 15 * 24 * 60 * 60 * 1000);
initializeClock('clockdiv', deadline);
</script>
</body>
</html>
	<!-- Timer Code Ends -->
	<?php
	if($_SESSION['curr_q_index'] > 0){
		$curr_ques = $ques_seq[$_SESSION['curr_q_index'] - 1];
		$ans_query = "SELECT * FROM questions WHERE Q_no='$curr_ques' AND qcode='$quiz_code'";
		$result = mysqli_query($con,$ans_query);
		$row = mysqli_fetch_array($result);

		$curr_q_index = $_SESSION['curr_q_index'];
		echo "current index = $curr_q_index ";

		if($row['type'] == "mcq"){
			if($row['answer'] == $_GET['ans']){
				$_SESSION['marks'] += $row['marks'];
			}
		}

		if($row['type'] == "multi_c_q"){
			$ser_answer = $row['answer'];
			$ans_array = unserialize($ser_answer);

			if($ans_array[0] == $_GET['status1'] && $ans_array[1] == $_GET['status2'] && $ans_array[2] == $_GET['status3'] && $ans_array[3] == $_GET['status4']){
				$_SESSION['marks'] += $row['marks'];
			}
		}

		if($row['type'] == "subjective"){
			$sub_ans = $_GET['sub_ans'];
			$query = "INSERT INTO sub_ans (qcode,Q_no,answer,eva_status,username) VALUES('$quiz_code','$curr_ques','$sub_ans','false','$username')";
			mysqli_query($con,$query);
		}
	}

	if($_SESSION['quiz_status'] == "off"){
		$_SESSION['quiz_status'] = "on";
		$_SESSION['marks'] = 0;
		echo "<br><br><br>you are in the quiz<br><br>";
	}


	if($_SESSION['curr_q_index'] >= $num_of_ques){
?>
		
	
	<div>
		you have completed your quiz !!!.
		<a href="homepage.php">go to home page</a>		
	</div>

<?php
		$query = "SELECT type FROM quizes";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_array($result);
		$type = $row['type'];
		$marks = $_SESSION['marks'];
		if($type == "mcq" || $type == "multi_c_q"){
			$marks_update = "UPDATE marks SET marks='$marks',eva_status='true' WHERE username='$username' AND qcode='$quiz_code'";
			mysqli_query($con,$marks_update);
		}

		else{
			$marks_update = "UPDATE marks SET marks='$marks',eva_status='false' WHERE username='$username' AND qcode='$quiz_code'";
			mysqli_query($con,$marks_update);
		}
		$_SESSION['quiz_status'] = "off";
		die();
	}
	
	$curr_ques = $ques_seq[$_SESSION['curr_q_index']++];
	$result = mysqli_query($con,"SELECT * FROM questions WHERE Q_no='$curr_ques' AND qcode='$quiz_code'");
	$row = mysqli_fetch_array($result);
?> 

<div>
	<?php 
		$ser_options = $row['options'];
		$options = unserialize($ser_options);

		$curr_q_num = $_SESSION['curr_q_index'];
		echo "Question :$curr_q_num"; 
		$question = $row['Question'];
		echo "$question";
	?>
</div>

<div>
	Media related to ques :
</div>

<?php	
	if($row["type"] == 'mcq'){
?>

<div>
	<form method="GET" action="thequiz.php">
		<input type="hidden" name="ans" value="off">
		
		
		
		<input type="radio" name="ans" value="a">
		<?php echo "$options[0]"; ?>
		<input type="radio" name="ans" value="b">
		<?php echo "$options[1]"; ?>
		<input type="radio" name="ans" value="c">
		<?php echo "$options[2]"; ?>
		<input type="radio" name="ans" value="d">
		<?php echo "$options[3]"; ?>
		<input type="submit" name="submit" value="submit">
	</form>
</div>

<?php 
	}
	else if($row["type"] == 'multi_c_q'){
?>

<div>
	<form method="GET" action="thequiz.php">
		<input type="hidden" name="status1" value="off">
		
		<input type="checkbox" name="status1" value="a">
		<?php echo "$options[0]"; ?>
		<input type="hidden" name="status2" value="off">
		<input type="checkbox" name="status2" value="b">
		<?php echo "$options[1]"; ?>
		<input type="hidden" name="status3" value="off">
		<input type="checkbox" name="status3" value="c">
		<?php echo "$options[2]"; ?>
		<input type="hidden" name="status4" value="off">
		<input type="checkbox" name="status4" value="d">
		<?php echo "$options[3]"; ?>
		<input type="submit" name="submit" value="submit">
	</form>
</div>

<?php
	}
	else{
?>

<div>
	<form method="GET" action="thequiz.php">
		
			
		
		<textarea name="sub_ans" placeholder="Ans here ..."></textarea>
		<input type="submit" name="submit" value="submit">
	</form>
</div>

<?php
	}
?>